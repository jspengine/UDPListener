﻿namespace NewsGPS.Mova.Core.Common.Gateway
{

    public class Options
    {
        public string IpAdrress { get; set; }
        public int? PortNumber { get; set; }
    }
   
}

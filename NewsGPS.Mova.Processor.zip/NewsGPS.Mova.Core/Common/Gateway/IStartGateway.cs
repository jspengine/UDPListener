﻿namespace NewsGPS.Mova.Core.Common.Gateway
{
    public interface IStartGateway
    {
        void Run();
    }
}
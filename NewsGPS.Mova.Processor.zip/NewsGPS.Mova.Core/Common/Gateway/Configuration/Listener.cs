﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewsGPS.Mova.Core.Common.Gateway.Configuration
{
    public class Listener
    {
        public string IpAddress { get; set; }
        public int[] Ports { get; set; }
    }
}
